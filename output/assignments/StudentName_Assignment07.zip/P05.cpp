#include <vector>
using namespace std; class Solution{int Gcd(int a,int b){while(b){int r=a%b;a=b;b=r;}return a;}public:int findGCD(vector<int>& nums){int smallest=nums[0],largest=nums[0];for(int value:nums){if(value<smallest)smallest=value;if(value>largest)largest=value;}return Gcd(smallest,largest);}};
