#include <iostream>
using namespace std; int Distance(int row,int col){int dr=row-2;if(dr<0)dr=-dr;int dc=col-2;if(dc<0)dc=-dc;return dr+dc;} int Run(){int matrix[5][5],r=0,c=0;for(int i=0;i<5;i++)for(int j=0;j<5;j++){cin>>matrix[i][j];if(matrix[i][j]==1){r=i;c=j;}}cout<<Distance(r,c)<<'\n';}

int main(){return Run();}
