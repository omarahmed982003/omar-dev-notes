#include <iostream>
using namespace std; void PrintAdvantages(const int values[],int n){int largest=-1,second=-1;for(int i=0;i<n;i++){if(largest==-1||values[i]>values[largest]){second=largest;largest=i;}else if(second==-1||values[i]>values[second])second=i;}for(int i=0;i<n;i++)cout<<values[i]-values[i==largest?second:largest]<<(i+1==n?'\n':' ');} int Run(){int tests;cin>>tests;while(tests--){int n,a[200000];cin>>n;for(int i=0;i<n;i++)cin>>a[i];PrintAdvantages(a,n);}}

int main(){return Run();}
