#include <iostream>
using namespace std; bool IsOdd(int); bool IsEven(int n){return n==0?true:IsOdd(n-1);} bool IsOdd(int n){return n==0?false:IsEven(n-1);} int Run(){int n;cin>>n;cout<<boolalpha<<IsEven(n)<<' '<<IsOdd(n)<<'\n';}

int main(){return Run();}
