#include <iostream>
using namespace std; int Sequence(int n){return n==1?2:Sequence(n-1)+3;} int Run(){int n;cin>>n;cout<<Sequence(n)<<'\n';}

int main(){return Run();}
