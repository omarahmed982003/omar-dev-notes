#include <iostream>
#include <limits>
using namespace std; int Run(){int size;cout<<"Enter size: ";if(!(cin>>size)||size<=0){cout<<"Invalid size\n";return 0;}int* values=new int[size];cout<<"Enter elements: ";long long sum=0;for(int* p=values;p<values+size;p++){if(!(cin>>*p)){delete[] values;cout<<"Invalid element\n";return 0;}sum+=*p;}cout<<"Sum: "<<sum<<"\nAverage: "<<static_cast<double>(sum)/size<<'\n';delete[] values;}

int main(){return Run();}
