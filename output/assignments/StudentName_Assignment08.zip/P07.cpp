#include <iostream>
using namespace std; void ReverseArray(int* arr,int size){if(size<2)return;int* left=arr;int* right=arr+size-1;while(left<right){int t=*left;*left=*right;*right=t;left++;right--;}} int Run(){int n;cin>>n;int* a=n?new int[n]:nullptr;for(int* p=a;p<a+n;p++)cin>>*p;ReverseArray(a,n);for(int* p=a;p<a+n;p++)cout<<*p<<(p+1==a+n?'\n':' ');delete[] a;}

int main(){return Run();}
