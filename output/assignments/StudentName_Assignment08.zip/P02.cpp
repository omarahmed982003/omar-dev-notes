#include <iostream>
using namespace std; int Sequence(int n){if(n==1)return 1;if(n==2)return 2;return Sequence(n-1)+Sequence(n-2);} int Run(){int n;cin>>n;cout<<Sequence(n)<<'\n';}

int main(){return Run();}
