#include <iostream>
using namespace std; int Calculate(int n,int result=0){while(n>0){result+=n*n;n--;}return result;} int Run(){int n;cin>>n;cout<<Calculate(n)<<'\n';}

int main(){return Run();}
