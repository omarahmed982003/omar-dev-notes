#include <iostream>
using namespace std; void SwapByReference(int& a,int& b){int t=a;a=b;b=t;} void SwapByPointer(int* a,int* b){int t=*a;*a=*b;*b=t;} int Run(){int a,b;cin>>a>>b;SwapByReference(a,b);cout<<a<<' '<<b<<'\n';SwapByPointer(&a,&b);cout<<a<<' '<<b<<'\n';}

int main(){return Run();}
