#include <iostream>
using namespace std; int CountOccurrences(const int* arr,int size,int target){int count=0;for(const int* p=arr;p<arr+size;p++)if(*p==target)count++;return count;} int Run(){int n,target;cin>>n;int* a=n?new int[n]:nullptr;for(int* p=a;p<a+n;p++)cin>>*p;cin>>target;cout<<CountOccurrences(a,n,target)<<'\n';delete[] a;}

int main(){return Run();}
