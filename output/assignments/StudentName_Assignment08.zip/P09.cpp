#include <iostream>
using namespace std; void Free(int** m,int rows){for(int i=0;i<rows;i++)delete[] m[i];delete[] m;} int Run(){int rows,cols;cout<<"Rows: ";if(!(cin>>rows)){cout<<"Invalid dimensions\n";return 0;}cout<<"Columns: ";if(!(cin>>cols)||rows<=0||cols<=0){cout<<"Invalid dimensions\n";return 0;}int** m=new int*[rows];for(int i=0;i<rows;i++)m[i]=new int[cols];cout<<"Elements:\n";for(int i=0;i<rows;i++)for(int j=0;j<cols;j++)if(!(cin>>m[i][j])){Free(m,rows);cout<<"Invalid element\n";return 0;}cout<<"Matrix:\n";for(int i=0;i<rows;i++){for(int j=0;j<cols;j++)cout<<m[i][j]<<(j+1==cols?'\n':' ');}for(int i=0;i<rows;i++){int sum=0;for(int j=0;j<cols;j++)sum+=m[i][j];cout<<"Row "<<i+1<<" Sum: "<<sum<<'\n';}Free(m,rows);}

int main(){return Run();}
