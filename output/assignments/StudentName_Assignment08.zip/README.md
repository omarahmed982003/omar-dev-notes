# Assignment 8

Compile each file independently with `g++ -std=c++17 -Wall -Wextra -pedantic P01.cpp -o P01`.

Tests used: base cases for recursion; zero/one/even/odd array sizes; invalid sizes and non-numeric elements; empty dynamic array; insert at 0 and size; invalid insert/delete indexes; deleting the final element.
