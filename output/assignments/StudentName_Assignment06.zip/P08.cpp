#include <vector>
using namespace std;
class Solution{public:int maximumWealth(vector<vector<int>>& accounts){int richest=0;for(const vector<int>& customer:accounts){int wealth=0;for(int amount:customer)wealth+=amount;if(wealth>richest)richest=wealth;}return richest;}};
