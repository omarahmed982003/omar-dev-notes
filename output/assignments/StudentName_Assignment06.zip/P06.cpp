#include <vector>
using namespace std;
class Solution{public:vector<int> getConcatenation(vector<int>& nums){vector<int> result;for(int copy=0;copy<2;copy++)for(int value:nums)result.push_back(value);return result;}};
