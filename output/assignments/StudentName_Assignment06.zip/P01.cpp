#include <iostream>
#include <string>
using namespace std;
int main(){int count;cin>>count;while(count--){string word;cin>>word;if(word.size()>10)cout<<word.front()<<word.size()-2<<word.back();else cout<<word;cout<<'\n';}}
