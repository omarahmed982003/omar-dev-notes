#include <iostream>
#include <string>
using namespace std;
int main(){string positions;cin>>positions;int run=1;for(int i=1;i<(int)positions.size();i++){run=positions[i]==positions[i-1]?run+1:1;if(run>=7){cout<<"YES\n";return 0;}}cout<<"NO\n";}
