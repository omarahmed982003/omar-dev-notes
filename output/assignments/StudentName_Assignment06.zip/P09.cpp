#include <string>
using namespace std;
class Solution{public:string defangIPaddr(string address){string result;for(char character:address){if(character=='.')result+="[.]";else result+=character;}return result;}};
