#include <iostream>
#include <string>
using namespace std;
int main(){string username;bool seen[26]={};int different=0;cin>>username;for(char letter:username)if(!seen[letter-'a']){seen[letter-'a']=true;different++;}cout<<(different%2?"IGNORE HIM!":"CHAT WITH HER!")<<'\n';}
