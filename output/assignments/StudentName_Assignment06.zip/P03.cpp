#include <iostream>
#include <string>
using namespace std;
int main(){int n,anton=0,danik=0;string games;cin>>n>>games;for(char winner:games){if(winner=='A')anton++;else danik++;}cout<<(anton>danik?"Anton":danik>anton?"Danik":"Friendship")<<'\n';}
