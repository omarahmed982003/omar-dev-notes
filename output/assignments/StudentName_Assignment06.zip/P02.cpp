#include <iostream>
using namespace std;
int main(){int n,k,scores[50],advanced=0;cin>>n>>k;for(int i=0;i<n;i++)cin>>scores[i];for(int i=0;i<n;i++)if(scores[i]>0&&scores[i]>=scores[k-1])advanced++;cout<<advanced<<'\n';}
