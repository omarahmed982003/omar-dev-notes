<?php
declare(strict_types=1);

echo "Hello, PHP!\n";
